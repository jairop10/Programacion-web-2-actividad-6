# API REST de Productos (Laravel)

Este proyecto es una API REST básica construida con Laravel que permite:

- Listar productos (GET)
- Agregar nuevos productos (POST)
- Editar productos existentes (PUT)

## Rutas de la API

| Método | Ruta                  | Descripción               |
|--------|-----------------------|---------------------------|
| GET    | /api/productos        | Obtener lista de productos |
| POST   | /api/productos        | Crear un nuevo producto   |
| PUT    | /api/productos/{id}   | Editar un producto por ID |

## Requisitos

- PHP >= 8.0
- Composer
- Base de datos MySQL

## Instrucciones

```bash
composer install
cp .env.example .env
php artisan key:generate
Configura la base de datos en .env
php artisan migrate
php artisan serve
```